var express = require('express');
var reload = require('reload');
var app = express();
var dataFile = require('./data/data.json');

app.set('port', process.env.PORT || 3000 );
app.set('appData', dataFile);
app.set('view engine', 'ejs');
app.set('views', 'app/views');

<<<<<<< HEAD
app.locals.siteTitle = 'Highlights';
// we need to say dataFile.data.highlights because in the Json file the files are nested in data
app.locals.allHighlights = dataFile.data.highlights;

=======
>>>>>>> parent of 214b2f4... 03_02e
app.use(express.static('app/public'));
app.use(require('./routes/index'));
app.use(require('./routes/highlights')); //fix

var server = app.listen(app.get('port'), function() {
  console.log('Listening on port ' + app.get('port'));
});

reload(server, app);
