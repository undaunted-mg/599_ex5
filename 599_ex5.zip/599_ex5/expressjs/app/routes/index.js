var express = require('express');
var router = express.Router();

router.get('/', function(req, res) {
  var dataFile = req.app.get('appData');
  var pagePhotos = [];
  var pageHighlights = dataFile.data.highlights;

//highlights in an array which is why can iterate through it
  dataFile.data.highlights.forEach(function(item) {
    pagePhotos = pagePhotos.concat(item.pagePhotos);
    //old one for refrence pagePhotos = pagePhotos.concat(item.artwork);

  });

<<<<<<< HEAD
  res.render('index', {
    pageTitle: 'Home',
    highlights: pageHighlights,
    pageID: 'home'
  });
=======
  res.render('index');
>>>>>>> parent of 214b2f4... 03_02e

});

module.exports = router;
